const sezioneMain = document.getElementById('sezione-main-interazioni');
if(sezioneMain && typeof PostDatabase === 'function') {
    sezioneMain.innerHTML = '<div class="loading-message">⏳ Caricamento delle dei post...</div>';
    PostDatabase(sezioneMain);
}