<?php
require_once 'database_config.php';
session_start();


function check_login() {
    if (isset($_SESSION['UTENTE'])) {
        return $_SESSION['UTENTE'];
        return $_SESSION['ID'];
    } else {
        return 0;
    }
}

?>