<?php

$database_config = array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'hw1'
);

?>