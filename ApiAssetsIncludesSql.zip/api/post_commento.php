<?php
require_once '../includes/auth.php';
header('Content-Type: application/json');

if(!check_login()) {
    echo json_encode(['success' => false, 'error' => 'Utente non autenticato']);
    exit;
}

if(!isset($_POST['commento']) || !isset($_POST['reddit_id']) || !isset($_POST['titolo']) || !isset($_POST['autore']) || !isset($_POST['subreddit'])) {
    echo json_encode(['success' => false, 'error' => 'Dati mancanti']);
    exit;
}

$conn = mysqli_connect($database_config['host'], $database_config['username'], $database_config['password'], $database_config['database']);
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Connessione al database fallita']);
    exit;
}

$user_id = $_SESSION['ID'];
$commento = mysqli_real_escape_string($conn, $_POST['commento']);
$reddit_id = mysqli_real_escape_string($conn, $_POST['reddit_id']);
$titolo = mysqli_real_escape_string($conn, $_POST['titolo']);
$autore = mysqli_real_escape_string($conn, $_POST['autore']);
$subreddit = mysqli_real_escape_string($conn, $_POST['subreddit']);
$url = isset($_POST['url']) ? mysqli_real_escape_string($conn, $_POST['url']) : '';
$thumbnail = isset($_POST['thumbnail']) ? mysqli_real_escape_string($conn, $_POST['thumbnail']) : '';
$contenuto = isset($_POST['contenuto']) ? mysqli_real_escape_string($conn, $_POST['contenuto']) : '';
$voto = isset($_POST['voto']) ? intval($_POST['voto']) : 0;


$check_post_query = "SELECT id FROM post WHERE reddit_id = '$reddit_id'";
$res = mysqli_query($conn, $check_post_query);
if(mysqli_num_rows($res) > 0) {
    $row = mysqli_fetch_assoc($res);
    $post_id = $row['id'];
} else {
    $inserisci_post_query = "INSERT INTO post (reddit_id, subreddit, titolo, autore, contenuto, url, thumbnail, voto) VALUES ('$reddit_id', '$subreddit', '$titolo', '$autore', '$contenuto', '$url', '$thumbnail', '$voto')";
    if(!mysqli_query($conn,$inserisci_post_query)) {
        echo json_encode(['success' => false, 'error' => 'Errore nel salvataggio del post: ' . mysqli_error($conn)]);
        exit();
    }
    $post_id = mysqli_insert_id($conn);
}

$inserisci_commento = "INSERT INTO commenti (post_id, user_id, contenuto) VALUES ('$post_id', '$user_id', '$commento')";

if(mysqli_query($conn,$inserisci_commento)) {
    $username_query = "SELECT username, avatar FROM utenti WHERE id = '$user_id'";
    $res_username_query = mysqli_query($conn,$username_query);
    $user_data = mysqli_fetch_assoc($res_username_query);

    echo json_encode(['success' => true, 'message' => 'Commento salvato con successo!', 'username' => $user_data['username'], 'user_avatar' => $user_data['avatar']]);
} else {
    echo json_encode(['success' => false, 'error' => 'Errore nel salvataggio del commento: ' . mysqli_error($conn)]);
}
mysqli_close($conn);

?>