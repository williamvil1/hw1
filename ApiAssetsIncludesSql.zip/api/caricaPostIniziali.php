<?php

require_once '../includes/auth.php';
header('Content-Type: application/json');


$conn = mysqli_connect($database_config['host'], $database_config['username'], $database_config['password'], $database_config['database']);
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Connessione al database fallita']);
    exit;
}


$user_id_loggato = $_SESSION['ID'] ?? null;

$user_id_loggato = mysqli_real_escape_string($conn, $user_id_loggato);

$sql_10_post = "SELECT p.id AS post_db_id, p.reddit_id, p.subreddit, p.titolo, p.autore, 
                   p.contenuto AS post_contenuto,
                   p.immagine_base64,
                   p.url, p.thumbnail, p.voto, p.tipo_contenuto, p.data_salvataggio,
                (SELECT v.tipo_voto FROM voti_utenti v WHERE v.post_id = p.id AND v.user_id = $user_id_loggato LIMIT 1) AS tipo_voto_utente
                FROM post p
                ORDER BY p.voto DESC, p.data_salvataggio DESC
                LIMIT 30";


$res_post = mysqli_query($conn, $sql_10_post);
$post_con_commenti_e_immagini = [];
if($res_post) {
    while($post_row = mysqli_fetch_assoc($res_post)) {
        $post_id_attuale = intval($post_row['post_db_id']);
        $post_row['commenti'] = [];

        $sql_commenti = "SELECT c.id AS comment_id, c.contenuto, c.data_commento, u.username, u.avatar AS user_avatar
                         FROM commenti c
                         JOIN utenti u ON c.user_id = u.id
                         WHERE c.post_id = '$post_id_attuale' 
                         ORDER BY c.data_commento ASC";
        
        $res_commenti = mysqli_query($conn, $sql_commenti);
        if($res_commenti) {
            while($commento_row = mysqli_fetch_assoc($res_commenti)) {
                $post_row['commenti'][] = $commento_row;
            }
            mysqli_free_result($res_commenti);
        } else {
            error_log("Errore nella query dei commenti: " . mysqli_error($conn));
        }
        $post_con_commenti_e_immagini[] = $post_row;
    }
    mysqli_free_result($res_post);
    echo json_encode(['success' => true, 'posts' => $post_con_commenti_e_immagini]);
} else {
    echo json_encode(['success' => false, 'error' => 'Errore nella query dei post']);
}

mysqli_close($conn);

?>