<?php
require_once '../includes/auth.php';
header('Content-Type: application/json');

if (!check_login()) {
    header('Location: login.php');
    echo json_encode(['success' => false, 'message' => 'Utente non autenticato. Accesso negato.']);
    exit();
}

$user_id = $_SESSION['ID'];
$response = [
    'success' => false,
    'message' => 'Nessuna operazione richiesta o dati non validi.',
    'updated_fields' => [
        'bio' => false,
        'password' => false
    ],
    'new_bio_html' => null,
    'require_logout' => false
];
$set_clauses = [];

$conn = mysqli_connect($database_config['host'], $database_config['username'], $database_config['password'], $database_config['database']);
if (!$conn) {
    $response['message'] = 'Connessione al database fallita: ' . mysqli_connect_error();
    echo json_encode($response);
    exit();
}

if (isset($_POST['bio'])){
    $bio_trim = trim($_POST['bio']);
    if(!empty($bio_trim)) {
        $escaped_bio = mysqli_real_escape_string($conn, $bio_trim);
        $set_clauses[] = "bio = '$escaped_bio'";
        $response['updated_fields']['bio'] = true;
        $response['new_bio_html'] = htmlspecialchars($bio_trim, ENT_QUOTES, 'UTF-8');
    } else {
        $set_clauses[] = "bio = '' ";
        $response['updated_fields']['bio'] = true;
        $response['new_bio_html'] = '<em>Nessuna biografia impostata.</em>';
    }
     
}

if (isset($_POST['password']) && !empty($_POST['password'])) {
    if (isset($_POST['conferma_password']) && $_POST['password'] === $_POST['conferma_password']) {
        $password_regex = '/^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,30}$/';
        if (preg_match($password_regex, $_POST['password'])) {
            $hashed_password = password_hash($_POST['password'], PASSWORD_BCRYPT);
            $escaped_password = mysqli_real_escape_string($conn, $hashed_password);
            $set_clauses[] = "password = '$escaped_password'";
            $response['message'] = 'Password aggiornata con successo.';
            $response['updated_fields']['password'] = true;
        } else {
            $response['message'] = 'La nuova password non rispetta i criteri di sicurezza.';
            echo json_encode($response);
            exit();
        }
    } else {
        $response['message'] = 'Le password non coincidono o la conferma è mancante.';
        echo json_encode($response);
        exit();
    }
}

if (!empty($set_clauses)) {
    $update_query_string = "UPDATE utenti SET " . implode(", ", $set_clauses) . " WHERE id = " . (int)$user_id; //implode unisce gli elementi dell'array in una stringa separata da ", "
    $res = mysqli_query($conn, $update_query_string);

    if ($res) {
        if (mysqli_affected_rows($conn) > 0) {
            $response['success'] = true;
            $messages = [];
            if ($response['updated_fields']['bio']) {
                $messages[] = "Bio";
            }
            if ($response['updated_fields']['password']) {
                $messages[] = "Password";
            }

             if (count($messages) > 0) {
                $response['message'] = implode(" e ", $messages) . (count($messages) > 1 ? " aggiornate" : " aggiornata") . " con successo.";
            } else {
                $response['message'] = "Profilo aggiornato con successo.";
            }

            if ($response['updated_fields']['password']) {
                $response['message'] .= " Per motivi di sicurezza, è necessario effettuare nuovamente il login. Sarai reindirizzato alla pagina di login.";
                $response['require_logout'] = true;
                session_destroy();
            }
        } else {
            $response['success'] = true;
            $response['message'] = 'Nessuna modifica effettiva ai dati (valori già presenti).';
        }

    } else {
        $response['message'] = 'Errore durante l\'aggiornamento del profilo.';
        error_log('Errore SQL in aggiorna_profilo.php: ' . mysqli_error($conn) . ' Query: ' . $update_query_string);
    }
} else {
    if ($response['message'] === 'Nessuna operazione richiesta o dati non validi.') {
         $response['message'] = 'Nessun dato valido fornito per l\'aggiornamento o password non valida.';
    }
}

mysqli_close($conn);
echo json_encode($response);
?>
