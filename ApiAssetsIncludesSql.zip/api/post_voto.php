<?php
require_once '../includes/auth.php';
header('Content-Type: application/json');

if(!check_login()) {
    echo json_encode(['success' => false, 'error' => 'Utente non autenticato']);
    exit;
}

if(!isset($_POST['reddit_id']) || !isset($_POST['titolo']) || !isset($_POST['autore']) || !isset($_POST['subreddit'])) {
    echo json_encode(['success' => false, 'error' => 'Dati mancanti']);
    exit;
}

$conn = mysqli_connect($database_config['host'], $database_config['username'], $database_config['password'], $database_config['database']);
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Connessione al database fallita']);
    exit;
}

$user_id = $_SESSION['ID'];
$reddit_id = mysqli_real_escape_string($conn, $_POST['reddit_id']);
$titolo = mysqli_real_escape_string($conn, $_POST['titolo']);
$autore = mysqli_real_escape_string($conn, $_POST['autore']);
$subreddit = mysqli_real_escape_string($conn, $_POST['subreddit']);
$url = isset($_POST['url']) ? mysqli_real_escape_string($conn, $_POST['url']) : '';
$thumbnail = isset($_POST['thumbnail']) ? mysqli_real_escape_string($conn, $_POST['thumbnail']) : '';
$contenuto = isset($_POST['contenuto']) ? mysqli_real_escape_string($conn, $_POST['contenuto']) : '';
$tipo_voto_utente = isset($_POST['tipo_voto_utente']) ? intval($_POST['tipo_voto_utente']) : 0;
$voto_attuale_post = isset($_POST['voto_attuale_post']) ? intval($_POST['voto_attuale_post']) : 0;


$check_post_query = "SELECT id, voto FROM post WHERE reddit_id = '$reddit_id'";
$res = mysqli_query($conn, $check_post_query);
if(mysqli_num_rows($res) > 0) {
    $row = mysqli_fetch_assoc($res);
    $post_id = $row['id'];
    $voto_attuale_post = intval($row['voto']);
} else {
    $inserisci_post_query = "INSERT INTO post (reddit_id, subreddit, titolo, autore, contenuto, url, thumbnail, voto) VALUES ('$reddit_id', '$subreddit', '$titolo', '$autore', '$contenuto', '$url', '$thumbnail', '$voto_attuale_post')";
    if(!mysqli_query($conn,$inserisci_post_query)) {
        echo json_encode(['success' => false, 'error' => 'Errore nel salvataggio del post: ' . mysqli_error($conn)]);
        exit();
    }
    $post_id = mysqli_insert_id($conn);
}


$voto_utente_precedente = 0;
$query_tipo_voto_utente = "SELECT tipo_voto FROM voti_utenti WHERE user_id = '$user_id' AND post_id = '$post_id'";
$res_tipo_voto_utente = mysqli_query($conn,$query_tipo_voto_utente);
if(mysqli_num_rows($res_tipo_voto_utente) > 0) {
    $row_voto_utente = mysqli_fetch_assoc($res_tipo_voto_utente);
    $voto_utente_precedente = intval($row_voto_utente['tipo_voto']);
}

$nuovo_voto_post = $voto_attuale_post;


$sql_voti_utenti = "";


if($tipo_voto_utente == 1) { // l'utente sta cliccando upvote
    if($voto_utente_precedente == 1) {
        $nuovo_voto_post -= 1;
        $sql_voti_utenti = "UPDATE voti_utenti SET tipo_voto = 0 WHERE user_id = '$user_id' AND post_id = '$post_id'";
    } elseif($voto_utente_precedente == -1) {
        $nuovo_voto_post += 2;
        $sql_voti_utenti = "UPDATE voti_utenti SET tipo_voto = 1 WHERE user_id = '$user_id' AND post_id = '$post_id'";
    } else { //l'utente non aveva votato
        $nuovo_voto_post += 1;
        $sql_voti_utenti = "INSERT INTO voti_utenti (user_id, post_id, tipo_voto) VALUES ('$user_id', '$post_id', 1) ON DUPLICATE KEY UPDATE tipo_voto = 1";
    }
} elseif($tipo_voto_utente == -1) { // l'utente sta cliccando downvote
    if($voto_utente_precedente == 1) {
        $nuovo_voto_post -= 2;
        $sql_voti_utenti = "UPDATE voti_utenti SET tipo_voto = -1 WHERE user_id = '$user_id' AND post_id = '$post_id'";
    } elseif($voto_utente_precedente == -1) {
        $nuovo_voto_post += 1;
        $sql_voti_utenti = "UPDATE voti_utenti SET tipo_voto = 0 WHERE user_id = '$user_id' AND post_id = '$post_id'";
    } else { //l'utente non aveva votato
        $nuovo_voto_post -= 1;
        $sql_voti_utenti = "INSERT INTO voti_utenti (user_id, post_id, tipo_voto) VALUES ('$user_id', '$post_id', -1) ON DUPLICATE KEY UPDATE tipo_voto = -1";
    }
} elseif($tipo_voto_utente == 0) { // l'utente sta cliccando per rimuovere il voto
        if($voto_utente_precedente == 1) { // l'utente aveva votato upvote
            $nuovo_voto_post -= 1;
            $sql_voti_utenti = "DELETE FROM voti_utenti WHERE user_id = '$user_id' AND post_id = '$post_id'";
        } elseif($voto_utente_precedente == -1) { // l'utente aveva votato downvote
            $nuovo_voto_post += 1;
            $sql_voti_utenti = "DELETE FROM voti_utenti WHERE user_id = '$user_id' AND post_id = '$post_id'";
        } else { //l'utente non aveva votato
             $sql_voti_utenti = "";
        }
}


if($sql_voti_utenti != "") {
    if(!mysqli_query($conn, $sql_voti_utenti)) {
        echo json_encode(['success' => false, 'error' => 'Errore nell\'aggiornamento del voto: ' . mysqli_error($conn)]);
        mysqli_close($conn);
        exit();
    }
}


$aggiorna_voto_post_query = "UPDATE post SET voto = '$nuovo_voto_post' WHERE id = '$post_id'";
if(!mysqli_query($conn, $aggiorna_voto_post_query)) {
    echo json_encode(['success' => false, 'error' => 'Errore nell\'aggiornamento del voto del post: ' . mysqli_error($conn)]);
    mysqli_close($conn);
    exit();
}

echo json_encode(['success' => true, 'nuovo_voto_post' => $nuovo_voto_post, 'nuovo_tipo_voto_utente' => $tipo_voto_utente]);
mysqli_close($conn);

?>