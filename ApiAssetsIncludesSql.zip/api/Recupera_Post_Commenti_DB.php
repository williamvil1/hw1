<?php
require_once '../includes/auth.php';
header('Content-Type: application/json');

if(!check_login()) {
    echo json_encode(['success' => false, 'error' => 'Utente non autenticato']);
    exit;
}

$user_id = $_SESSION['ID'];


$conn = mysqli_connect($database_config['host'], $database_config['username'], $database_config['password'], $database_config['database']);
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Connessione al database fallita']);
    exit;
}

$user_id_escaped = mysqli_real_escape_string($conn, $user_id);

$post_query = "SELECT DISTINCT p.id AS post_db_id, p.reddit_id, p.subreddit, p.titolo, p.autore, 
                   p.contenuto AS testo_contenuto,
                   p.immagine_base64,
                   p.url, p.thumbnail, p.voto, p.tipo_contenuto, p.data_salvataggio,
                   (SELECT v_sub.tipo_voto 
                    FROM voti_utenti v_sub
                    WHERE v_sub.post_id = p.id AND v_sub.user_id = '$user_id_escaped'
                    LIMIT 1) AS tipo_voto_utente
               FROM post p
               LEFT JOIN commenti c ON p.id = c.post_id AND c.user_id = '$user_id_escaped'
               LEFT JOIN voti_utenti v_main ON p.id = v_main.post_id AND v_main.user_id = '$user_id_escaped'
               WHERE c.user_id IS NOT NULL OR v_main.user_id IS NOT NULL 
               ORDER BY p.data_salvataggio DESC, p.id DESC";

$post_query_result = mysqli_query($conn, $post_query);
$dati_finali = [];

if($post_query_result) {
    while($post_row = mysqli_fetch_assoc($post_query_result)) {
        $current_post_db_id = intval($post_row['post_db_id']);

        $posts = [
            'id' => $current_post_db_id,
            'post_db_id' => $current_post_db_id,
            'reddit_id' => $post_row['reddit_id'],
            'subreddit' => $post_row['subreddit'],
            'titolo' => $post_row['titolo'],
            'autore' => $post_row['autore'],
            'post_contenuto' => $post_row['testo_contenuto'],
            'immagine_base64' => $post_row['immagine_base64'],
            'url' => $post_row['url'],
            'thumbnail' => $post_row['thumbnail'],
            'voto' => $post_row['voto'],
            'tipo_voto_utente' => $post_row['tipo_voto_utente'],
            'tipo_contenuto' => $post_row['tipo_contenuto'],
            'commenti' => []
        ];


$commento_query = "SELECT c.id AS comment_id, c.contenuto, c.data_commento, u.username, u.avatar AS user_avatar
                        FROM commenti c
                        JOIN utenti u ON c.user_id = u.id
                        WHERE c.post_id = '$current_post_db_id' 
                        ORDER BY c.data_commento ASC";

$commento_query_result = mysqli_query($conn, $commento_query);

if($commento_query_result) {
    while($commento_row = mysqli_fetch_assoc($commento_query_result)) {
        $posts['commenti'][] = [
            'comment_id' => $commento_row['comment_id'],
            'contenuto' => $commento_row['contenuto'],
            'data_commento' => $commento_row['data_commento'],
            'username' => $commento_row['username'],
            'user_avatar' => $commento_row['user_avatar']
        ];
    }
    mysqli_free_result($commento_query_result);
    } else {
    error_log("Errore nella query dei commenti per post ID $current_post_db_id: " . mysqli_error($conn));
   }
$dati_finali[] = $posts;
 }
mysqli_free_result($post_query_result);
} else {
    error_log("Errore nella query dei post: " . mysqli_error($conn));
    echo json_encode(['success' => false, 'error' => 'Errore nel recuperare i post']);
    mysqli_close($conn);
    exit();
}

echo json_encode([ 'success' => true, 'data' => $dati_finali]);
mysqli_close($conn);
?>