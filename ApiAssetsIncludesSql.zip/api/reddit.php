<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$client_id = 'secret';
$client_secret = 'secret';


$subreddit = isset($_POST['subreddit']) ? $_POST['subreddit'] : 'gaming';

$ch = curl_init('https://www.reddit.com/api/v1/access_token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Basic ' . base64_encode($client_id . ':' . $client_secret),
    'User-Agent: php:ProgettoTest:v1.0 (by /u/williamvil)'
]);

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (isset($data['access_token'])) {
    $token = $data['access_token'];
    
    $url = "https://oauth.reddit.com/r/{$subreddit}/hot?limit=10";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$token}",
        'User-Agent: php:ProgettoTest:v1.0 (by /u/williamvil)'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    

    echo $response;
} else {
    echo json_encode(['error' => 'Failed to get token']);
}
?>